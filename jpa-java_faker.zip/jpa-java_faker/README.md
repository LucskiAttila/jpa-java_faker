jpa-example
===========

Example project that demonstrates how to use JPA with [Hibernate](https://hibernate.org/) and [H2](https://www.h2database.com/) in Java SE.
